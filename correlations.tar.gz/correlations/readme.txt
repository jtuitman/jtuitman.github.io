This is code I wrote in 2016 to generate (random) correlation matrices satisfying various constraints.

The underlying algorithms are joint work with Steven Vanduffel and Jing Yao:

https://doi.org/10.1016/j.spl.2020.108868
