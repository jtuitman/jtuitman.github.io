This is the Coleman MAGMA library v1.3 for computing Coleman
integrals on general curves over Q. For information on how to
use the code see examples.pdf.

April 2018

Jan Tuitman (joint work with Jennifer Balakrishnan)
jan.tuitman@kuleuven.
