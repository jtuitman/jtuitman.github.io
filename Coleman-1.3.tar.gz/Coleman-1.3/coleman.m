Qx<x>:=PolynomialRing(RationalField());
Qxy<y>:=PolynomialRing(Qx);

load "auxpolys.m";
load "coho.m";
load "froblift.m";
load "reductions.m";
load "singleintegrals.m";
load "applications.m";
