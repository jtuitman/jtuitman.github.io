#include "mpoly.h"

void mpoly_clear(mpoly_t rop, const ctx_t ctx)
{
    mpoly_zero(rop, ctx);
}

