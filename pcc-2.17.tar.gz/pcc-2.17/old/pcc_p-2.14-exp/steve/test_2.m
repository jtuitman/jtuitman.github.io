load "auxpolys_p.m";
load "froblift_2.m";
load "coho_p.m";

Zx<x>:=PolynomialRing(IntegerRing());
Zxy<y>:=PolynomialRing(Zx);

// Example 1: (hyperelliptic small p)

Q:=y^2-x^3-1;
p:=7;
N:=100;

r,Delta,s:=auxpolys(Q);
W0:=mat_W0(Q);

time Fpy:=froblift(Q,p,N,r,Delta,s,W0);
time square:=Fpy^2;

print "";

// Example 2: (hyperelliptic large p)

Q:=y^2-x^3-1;
p:=10007;
N:=20;

r,Delta,s:=auxpolys(Q);
W0:=mat_W0(Q);

time Fpy:=froblift(Q,p,N,r,Delta,s,W0);
time square:=Fpy^2;

print "";

// Example 3: (large genus non hyperelliptic, small p)

Q:=y^5+(x^5+5*x^4+7*x^3+3*x^2+2*x+7)*y^4+(2*x^5+7*x^4+6*x^2+3*x+6)*y^3+(2*x^5+3*x^4+5*x^3+2*x^2+3*x+8)*y^2+(3*x^5+2*x^4+2*x^3+4*x^2+x+2)*y+(3*x^5+7*x^4+2*x^3+4*x^2+2*x+5);
p:=11;
N:=20;

r,Delta,s:=auxpolys(Q);
W0:=mat_W0(Q);

time Fpy:=froblift(Q,p,N,r,Delta,s,W0);
time square:=Fpy^2;


