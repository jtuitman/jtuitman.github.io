getrings:=function(p,Q,r,N)

  // Construct rings mod p^N.

  O:=IntegerRing(p^N);
  Oz<z>:=LaurentSeriesRing(O);
  
  S<x>:=PolynomialRing(Oz);
  
  lc:=LeadingCoefficient(r);
  rnew:=S!0;
  for i:=0 to Degree(r) do
    rnew:=rnew+(O!Coefficient(r,i))*(S.1)^i;
  end for;
  rnew:=rnew/lc;
  r:=rnew;
  
  S<x>:=quo<S|r-z>;

  R<y>:=PolynomialRing(S);
  Qnew:=R!0;
  for i:=0 to Degree(Q) do
    coef:=Coefficient(Q,i);
    for j:=0 to Degree(coef) do
      Qnew:=Qnew+Coefficient(coef,j)*(S.1)^j*(R.1)^i;
    end for;
  end for;

  Q:=Qnew;
  R<y>:=quo<R|Q>;
  
  return O,Oz,S,R;
end function;


froblift:=function(Q,p,N,r,Delta,s,W0);

  d:=Degree(Q);

  // 1) Compute matrix of F_p on R w.r.t. basis [y^i]

  lc:=LeadingCoefficient(r);

  rQx:=Parent(Numerator(W0[1,1]))!r;
  DeltaQx:=Parent(Numerator(W0[1,1]))!Delta;
  rQx:=rQx/lc;
  DeltaQx:=DeltaQx/lc;

  O,Oz,S,R:=getrings(p,Q,r,N);
  x:=S.1; y:=R.1; z:=Oz.1;

  cnt:=1;
  while (rQx^cnt mod DeltaQx ne 0) do
    cnt:=cnt+1;
  end while;
  gQx:=rQx^cnt div DeltaQx;

  prec:=[];
  k:=N;
  while k gt 1 do
    prec:=Append(prec,k);
    k:=Ceiling(k/2);
  end while;
  prec:=Reverse(prec);

  alpha:=S!(z^(-p));
  beta:=y^p;	

  for i:=1 to #prec do

    Oi,Ozi,Si,Ri:=getrings(p,Q,r,prec[i]);

    alpha_new:=Si!0;
    for j:=0 to Degree(alpha) do
      coef:=Coefficient(alpha,j);
      val:=Valuation(coef);
      alpha_new:=alpha_new+(Ozi!Coefficients(coef))*(Ozi.1)^val*(Si.1)^j;
    end for;
    alpha:=alpha_new;

    beta_new:=Ri!0;
    for j:=0 to Degree(beta) do
      coef:=Coefficient(beta,j);
      for k:=0 to Degree(coef) do
        coef1:=Coefficient(coef,k);
        if coef1 ne 0 then
          val:=Valuation(coef1);
          beta_new:=beta_new+(Ozi!Coefficients(coef1))*(Ozi.1)^val*(Si.1)^k*(Ri.1)^j;
        end if;
      end for;
    end for;
    beta:=beta_new;

    xpi:=(Si.1)^p;				
    rxp:=Evaluate(r,xpi)*(Oi!lc)^(-1);
    							
    alpha:=alpha*(2-alpha*rxp); // alpha=F_p(1/r)
    alpha_power:=alpha^cnt;

    gxp:=Si!0;
    for j:=0 to Degree(gQx) do
      gxp:=gxp+(Oi!Coefficient(gQx,j))*xpi^j;
    end for;

    alpha1:=gxp*alpha_power;    // alpha1=F_p(1/Delta)

    betapowers:=[];
    betapowers[1]:=Ri!1;
    for j:=1 to Degree(Q) do
      betapowers[j+1]:=beta*betapowers[j];
    end for;

    Qxpbeta:=Ri!0; 
    for j:=0 to Degree(Q) do
      coef:=Coefficient(Q,j);
      temp:=Si!0;
      for k:=0 to Degree(coef) do
        temp:=temp+(Oi!Coefficient(coef,k))*(xpi)^k; 
      end for;
      Qxpbeta:=Qxpbeta+temp*betapowers[j+1];
    end for;

    sxpbeta:=Ri!0;
    for j:=0 to Degree(s) do
      coef:=Coefficient(s,j);
      temp:=Si!0;
      for k:=0 to Degree(coef) do
        temp:=temp+(Oi!Coefficient(coef,k))*(xpi)^k;
      end for;
      sxpbeta:=sxpbeta+temp*betapowers[j+1];
    end for;
    sxpbeta:=sxpbeta*(Oi!lc)^(-1);							

    beta:=beta-Qxpbeta*sxpbeta*alpha1;

  end for;

  return beta;

end function;
