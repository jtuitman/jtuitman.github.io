////////////////////////////////////////////////// 
// This code is part of the pcc_q MAGMA library //
//                                              //
// copyright (c) 2016 Jan Tuitman               //
//////////////////////////////////////////////////

getrings:=function(p,N);

  // Construct rings mod p^N.

  O<a>:=PolynomialRing(IntegerRing(p^N));
  Ox<x>:=PolynomialRing(O);
  S<z>:=LaurentSeriesRing(Ox); // z=r
  R<y>:=PolynomialRing(S);
  return O,Ox,S,R;
end function;

sigma_Ox:=function(f,p,n,N);

  // Apply p-th power Frobenius to an element of Ox (coefficientwise).

  Z:=IntegerRing();
  Zq:=UnramifiedExtension(pAdicRing(p,N),n);
  C:=Coefficients(f);
  for i:=1 to #C do
    D:=Coefficients(GaloisImage(Zq!Coefficients(C[i]),1));
    E:=[];
    for i:=1 to #D do
      E[i]:=Z!D[i];
    end for;
    C[i]:=BaseRing(Parent(f))!E;
  end for;
  return Parent(f)!C;
end function;

sigma_R:=function(f,p,n,N);

  // Apply p-th power Frobenius to an element of R (coefficientwise).

  C:=Coefficients(f);
  for i:=1 to #C do
    if C[i] ne 0 then
      v:=Valuation(C[i]);
      D:=Coefficients(C[i]);
      for j:=1 to #D do
        D[j]:=sigma_Ox(D[j],p,n,N);
      end for;
      C[i]:=(BaseRing(Parent(f)).1)^v*(BaseRing(Parent(f))!D);
    end if;
  end for;
  return Parent(f)!C;
end function;

reduce_mod_m_Ox:=function(f,m); 

  // Reduce an element of Ox modulo the defining polynomial m of O.

  C:=Coefficients(f);
  for i:=1 to #C do
    C[i]:=C[i] mod (BaseRing(Parent(f))!m);
  end for;
  return Parent(f)!C;
end function;

reduce_mod_m_R:=function(f,m); 

  // Reduce an element of Ox modulo the defining polynomial m of O.

  C:=Coefficients(f);
  for i:=1 to #C do
    if C[i] ne 0 then
      v:=Valuation(C[i]);
      D:=Coefficients(C[i]);
      j:=1;
      for j:=1 to #D do
        D[j]:=reduce_mod_m_Ox(D[j],m);
      end for;
      C[i]:=BaseRing(Parent(f))!(BaseRing(Parent(f)).1)^v*(BaseRing(Parent(f))!D);
    end if;  
  end for;
  return Parent(f)!C;
end function;

div_rem:=function(f,r,m);

  // Compute quotient and remainder of f/r for element f,r of Ox.

  quot  := f div r;
  rem   := f-quot*r;
  return reduce_mod_m_Ox(quot,m), reduce_mod_m_Ox(rem,m);
end function;

div_rem_precomp:=function(f,r,m,L);

  // Compute quotient and remainder of f/r for element f,r of Ox.

  g:=f mod (Parent(f).1)^(Degree(r));
  h:=f-g;
  quot:=Parent(f)!0;
  rem:=g;
  for i:=0 to Degree(r)-2  do
    quot:=quot+(Parent(f)!L[i+1][1])*Coefficient(h,i+Degree(r));
    rem:=rem+(Parent(f)!L[i+1][2])*Coefficient(h,i+Degree(r));
  end for;
  quot:=reduce_mod_m_Ox(quot,m);
  rem:=reduce_mod_m_Ox(rem,m);
  return quot,rem;
end function;

radix_reduce:=function(f,r,m,L); 

  // Eliminate powers of x >= deg(r) in f.

  C:=Coefficients(f);
  for i:=1 to #C do
    if C[i] ne 0 then
      v:=Valuation(C[i]);
      D:=Coefficients(C[i]);
      j:=1;
      while j le #D do
        D[j]:=reduce_mod_m_Ox(D[j],m);
        if Degree(D[j]) ge Degree(r) then
          if Degree(D[j]) gt 2*Degree(r)-2 then
            quot,rem := div_rem(D[j],BaseRing(BaseRing(Parent(f)))!r,m);
            D[j]     := rem;
            if #D lt j+1 then
              D[j+1]:=quot;
            else
              D[j+1]:=D[j+1]+quot;
            end if;
          else
            quot,rem := div_rem_precomp(D[j],BaseRing(BaseRing(Parent(f)))!r,m,L);
            D[j]     := rem;
            if #D lt j+1 then
              D[j+1]:=quot;
            else
              D[j+1]:=D[j+1]+quot;
            end if;
          end if;      
        end if;
        j:=j+1;
      end while;
      C[i]:=BaseRing(Parent(f))!(BaseRing(Parent(f)).1)^v*(BaseRing(Parent(f))!D);
    end if;  
  end for;
  return Parent(f)!C; 
end function;

push_to_Ri:=function(f,Ri)

  // ! behaves wrong, when an element f does not contain any a's, trying to correct this...

  Si:=BaseRing(Ri);
  Oxi:=BaseRing(Si);
  Oi:=BaseRing(Oxi);
  g:=Ri!0;
  C:=Coefficients(f);
  for i:=1 to #C do
    D:=Coefficients(C[i]);
    v:=Valuation(C[i]);
    for j:=1 to #D do
      E:=Coefficients(D[j]);
      for k:=1 to #E do
        g:=g+(Oi!E[k])*(Oxi.1)^(k-1)*(Si.1)^(j-1+v)*(Ri.1)^(i-1);
      end for;
    end for;
  end for;
  return g;
end function;

reduce_mod_Q:=function(f,Q,r,m,L); 

  // Eliminate powers of y >= deg(Q).

  f:=radix_reduce(f,r,m,L);
  Q:=radix_reduce(push_to_Ri(Q,Parent(f)),r,m,L);

  while Degree(f) ge Degree(Q) do
    f:=radix_reduce(f-Coefficient(f,Degree(f))*(Parent(f).1)^(Degree(f)-Degree(Q))*(push_to_Ri(Q,Parent(f))),r,m,L);
  end while;

  return f;  
end function;

xpforx:=function(f,xp,r,m,L); 

  // Substitute x^p for x in an element of R (without any z).

  R:=Parent(f);
  S:=BaseRing(R);
  Ox:=BaseRing(S);
  O:=BaseRing(Ox);

  // Determine the degree in x of f.
  
  C:=Coefficients(f);
  degxf:=0;
  for i:=1 to #C do
    if (C[i] ne 0) and (Degree(Coefficients(C[i])[1]) gt degxf) then 
      degxf:=Degree(Coefficients(C[i])[1]);
    end if;
  end for;

  // Compute the radix_reduction of (x^p)^k for k up to degxf.

  xppow:=[];
  xppow[1]:=Parent(f)!1;
  xppow[2]:=xp;
  for i:=2 to degxf do
    xppow:=Append(xppow,radix_reduce(xppow[i]*xp,r,m,L));
  end for;

  // Substitute x^p into f(-,y).

  out:=Parent(f)!0;
  for i:=1 to #C do
    D:=Coefficients(Coefficients(C[i])[1]); 
    for j:=1 to #D do
      out:=out+D[j]*xppow[j]*(Parent(f).1)^(i-1);
    end for;
  end for;

  out:=radix_reduce(out,r,m,L); 

  return out;
end function;

pow:=function(f,k,Q,r,m,L);

  // computes f^k for an element f in R

  if k eq 0 then
    return Parent(f)!1;
  end if;

  digits:=Intseq(k,2);
  f2i:=f;
  
  if digits[1] eq 1 then 
    fpow:=f;
  else
    fpow:=Parent(f)!1;
  end if;

  for i:=2 to #digits do
    f2i:=reduce_mod_Q(f2i*f2i,Q,r,m,L);
    if digits[i] eq 1 then
      fpow:=reduce_mod_Q(fpow*f2i,Q,r,m,L);
    end if;
  end for;

  return fpow;
  
end function;


froblift:=function(Q,p,n,N,r,Delta,s,W0);

  // Compute the matrix of Fp on R w.r.t. basis [b^0_i/r]
  
  O,Ox,S,R:=getrings(p,N);
  
  d:=Degree(Q);
  C:=Coefficients(Q); 

  Qnew:=R!0;
  for i:=1 to #C do
    D:=Coefficients(C[i]);
    for j:=1 to #D do
      Qnew:=Qnew+(O!D[j])*(Ox.1)^(j-1)*(R.1)^(i-1);
    end for;
  end for;
  Q:=Qnew;

  rK:=Zax_to_Kx(r,Parent(Numerator(W0[1,1])));
  DeltaKx:=Zax_to_Kx(Delta,Parent(Numerator(W0[1,1])));
  lc_rK:=LeadingCoefficient(rK);
  rK:=rK/lc_rK;
  DeltaK:=DeltaKx/lc_rK;
  
  r:=(Ox!Coefficients(r));
  Delta:=(Ox!Coefficients(Delta));
  
  C:=Coefficients(s); 
  snew:=R!0;
  for i:=1 to #C do
    D:=Coefficients(C[i]);
    for j:=1 to #D do
      snew:=snew+(O!D[j])*(Ox.1)^(j-1)*(R.1)^(i-1);
    end for;
  end for;
  s:=snew;

  C:=[];
  for i:=0 to n do
    C[i+1]:=IntegerRing()!Coefficient(DefiningPolynomial(FiniteField(p^n)),i);
  end for;
  m:=O!C;

  lc_r:=BaseRing(O)!LeadingCoefficient(r);
  r:=r/lc_r;
  Delta:=Delta/lc_r; 
  s:=s/lc_r;

  Qsigma:=sigma_R(Q,p,n,N);
  rsigma:=sigma_Ox(r,p,n,N);
  Deltasigma:=sigma_Ox(Delta,p,n,N);
  ssigma:=sigma_R(s,p,n,N);

  cnt:=1;
  while (rK^cnt mod DeltaKx ne 0) do
    cnt:=cnt+1;
  end while;
  g:=Ox!0;
  C:=Coefficients(rK^cnt div DeltaK);
  for i:=1 to #C do
    for j:=1 to n do
      g:=g+(BaseRing(O)!C[i][j])*(O.1)^(j-1)*(Ox.1)^(i-1);
    end for;
  end for;

  gsigma:=sigma_Ox(g,p,n,N);
  
  prec:=[];
  k:=N;
  while k gt 1 do
    prec:=Append(prec,k);
    k:=Ceiling(k/2);
  end while;
  prec:=Reverse(prec);

  L:=[];
  for i:=Degree(r) to 2*Degree(r)-2 do
    quot,rem:=div_rem((Ox.1)^i,Ox!r,m); //
    L:=Append(L,[quot,rem]);
  end for;

  // 1) Compute F_p(1/r), F_p(1/Delta) and F_p(y)

  xp:=pow(R!(Ox.1),p,Q,r,m,L);
  alpha:=R!((S.1)^(-p));
  beta:=pow(R.1,p,Q,r,m,L);
  
  for i:=1 to #prec do

    Oi,Oxi,Si,Ri:=getrings(p,prec[i]);
    xpi:=pow(Ri!(Oxi.1),p,Q,r,m,L);

    rxp:=xpforx(Ri!(Oxi!rsigma),xpi,r,m,L);

    alpha:=(Ri!alpha); //
    alpha:=radix_reduce(alpha*radix_reduce(Ri!2-alpha*rxp,r,m,L),r,m,L); // alpha=F_p(1/r)

    alpha_power:=alpha;
    for j:=2 to cnt do
      alpha_power:=radix_reduce(alpha_power*alpha,r,m,L);
    end for; 
    gxp:=xpforx(Ri!(Oxi!gsigma),xpi,r,m,L); 
    alpha1:=radix_reduce(gxp*alpha_power,r,m,L); // alpha1=F_p(1/Delta)

    powers:=[];
    powers[1]:=Ri!1;
    for j:=2 to d+1 do
      powers[j]:=reduce_mod_Q(push_to_Ri(beta,Ri)*powers[j-1],Q,r,m,L);
    end for;

    Qxp:=xpforx(push_to_Ri(Qsigma,Ri),xpi,r,m,L);
    sxp:=xpforx(push_to_Ri(ssigma,Ri),xpi,r,m,L);

    evalQxp:=Ri!0;
    for j:=0 to d do
      evalQxp:=evalQxp+Coefficient(Qxp,j)*powers[j+1]; // most likely something wrong here
    end for;
    evalQxp:=radix_reduce(evalQxp,r,m,L); // this has to be wrong, not zero mod p..., check everything up to this point mod p.
    evalsxp:=Ri!0;
    for j:=0 to Degree(s) do
      evalsxp:=evalsxp+Coefficient(sxp,j)*powers[j+1];
    end for;
    evalsxp:=radix_reduce(evalsxp,r,m,L);
    beta:=radix_reduce(push_to_Ri(beta,Ri)-reduce_mod_Q(radix_reduce(evalQxp*evalsxp,r,m,L),Q,r,m,L)*(Ri!alpha1),r,m,L); // beta=F_p(y)
  end for;
  
  // (slow) optional tests:
  // radix_reduce(alpha*xpforx(R!(Ox!rsigma),xpi,r,m,L),r,m,L) eq 1;          
  // radix_reduce(alpha1*xpforx(R!(Ox!Deltasigma),xpi,r,m,L),r,m,L) eq 1; 
  // reduce_mod_Q(Evaluate(xpforx(Qsigma,xpi,r,m,L),beta),Q,r,m,L) eq 0;
  
  // 2) Compute matrix of F_p on R w.r.t. basis [y^i/r]

  alpha:=R!alpha;
  beta:=R!beta;
  
  mat:=ZeroMatrix(S,d,d); 
  Fpyir:=(S.1)*(alpha);        		 // r*F_p(y^0/r)
  for i:=1 to d do
    mat[1,i]:=Coefficient(Fpyir,i-1);
  end for;
  for i:=2 to d do
    Fpyir:=reduce_mod_Q(beta*Fpyir,Q,r,m,L); // r*F_p(y^(j+1)/r) = F_p(y)*(r*F_p(y^j/r))
    for j:=1 to d do
      mat[i,j]:=Coefficient(Fpyir,j-1);
    end for;
  end for;

  // 3) Compute the matrix of F_p on R w.r.t. basis [b^0_i/r] (i.e. Fp(W0)*mat*W0^(-1))

  W0inv:=W0^(-1);
  ordrW0inv:=ord_r_mat(W0inv,rK);
  W0invS:=ZeroMatrix(S,d,d);
  for i:=1 to d do
    for j:=1 to d do
      C:=Coefficients(Numerator((Parent(W0[1,1])!rK)^(-ordrW0inv)*W0inv[i,j]));
      num:=Ox!0;
      for k:=1 to #C do
        for l:=1 to n do
          num:=num+(BaseRing(O)!C[k][l])*(Ox.1)^(k-1)*(O.1)^(l-1);
        end for;
      end for;
      W0invS[i,j]:=Coefficient(radix_reduce(R!((S.1)^(ordrW0inv)*num),r,m,L),0); // Compute S!W0^(-1)
    end for;
  end for;
  
  mat:=mat*W0invS; // Compute mat*W0^(-1)
  for i:=1 to d do
    for j:=1 to d do
      mat[i,j]:=Coefficient(radix_reduce(R!mat[i,j],r,m,L),0); 
    end for;
  end for;
  
  ordrW0:=ord_r_mat(W0,rK);
  FpW0S:=ZeroMatrix(S,d,d);
  for i:=1 to d do
    for j:=1 to d do
      numW0ij:=Numerator((Parent(W0[1,1])!rK)^(-ordrW0)*W0[i,j]);
      C:=Coefficients(numW0ij);
      numW0ijOx:=Ox!0;
      for k:=1 to #C do
        for l:=1 to n do
          numW0ijOx:=numW0ijOx+(BaseRing(O)!C[k][l])*(Ox.1)^(k-1)*(O.1)^(l-1);
        end for; 
      end for;   
      FpW0S[i,j]:=Coefficient(radix_reduce(pow(alpha,-ordrW0,Q,r,m,L)*xpforx(R!sigma_Ox(numW0ijOx,p,n,N),xp,r,m,L),r,m,L),0); // Compute S!Fp(W0) ///// change
    end for;
  end for;
 
  mat:=FpW0S*mat; // Compute Fp(W0)*mat*W0^(-1)
  for i:=1 to d do
    for j:=1 to d do 
      mat[i,j]:=Coefficient(radix_reduce(R!mat[i,j],r,m,L),0);
    end for;
  end for;
  
  return mat; // matrix of Fp on R w.r.t. basis [b^0_i/r]

end function;

frobenius:=function(w,Q,p,n,N,r,frobmatb0r);

  // Compute F_p(sum w_i b^0_i dx/r) mod p^N.

  O,Ox,S,R:=getrings(p,N-1);
  a:=O.1; x:=Ox.1; y:=R.1; z:=S.1;

  d:=Degree(Q);
  Q:=R!Q;

  Sd:=RSpace(S,d);

  r:=(Ox!Coefficients(r)); 
  lc_r:=LeadingCoefficient(r);
  r:=r/lc_r;

  C:=[];
  for i:=0 to n do
    C[i+1]:=IntegerRing()!Coefficient(DefiningPolynomial(FiniteField(p^n)),i);
  end for;
  m:=O!C;

  L:=[];
  for i:=Degree(r) to 2*Degree(r)-2 do
    quot,rem:=div_rem((Ox.1)^i,Ox!r,m);
    L:=Append(L,[quot,rem]);
  end for;

  xp_minus_one:=pow(R!(Ox!x),p-1,Q,r,m,L);		   
  xp:=radix_reduce(xp_minus_one*(R!(Ox!x)),r,m,L); 

  frob:=Sd!0;
  for i:=1 to d do
    temp:=radix_reduce((xp_minus_one)*xpforx(R!sigma_Ox(Ox!Coefficients(w[i]),p,n,N),xp,r,m,L),r,m,L);
    for j:=1 to d do
      frob[j]:=Coefficient(radix_reduce(frob[j]+frobmatb0r[i,j]*temp,r,m,L),0);
    end for;
  end for;

  O,Ox,S,R:=getrings(p,N);
  Sd:=RSpace(S,d); 
  frob:=p*(Sd!frob); 

  return frob;   
end function;


