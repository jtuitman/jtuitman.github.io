////////////////////////////////////////////////// 
// This code is part of the pcc_q MAGMA library //
//                                              //
// copyright (c) 2016 Jan Tuitman               //
//////////////////////////////////////////////////

reduce_mod_pN_Q:=function(f,p,N);

  // Reduce a rational number f mod p^N.

  Z:=IntegerRing();
  if f ne 0 then
    ord:=Valuation(f,p);
    if ord ge N then
      f:=0;
    else
      m:=p^(N-ord);
      Zmodm:=IntegerRing(m);
      unit:=f/(p^ord);
      f:=p^ord*(RationalField()!Z!((Zmodm!Numerator(unit))/(Zmodm!Denominator(unit))));
    end if;
  end if;
  return f;
end function;

reduce_mod_pN_K:=function(f,p,N);

  // Reduce an element of K mod p^N.

  C:=Eltseq(f);
  for i:=1 to #C do
    C[i]:=reduce_mod_pN_Q(C[i],p,N);
  end for;
  return Parent(f)!C;
end function;

reduce_mod_pN_Kx:=function(f,p,N);

  // Reduce a polynomial f over K mod p^N.

  C:=Coefficients(f);
  for i:=1 to #C do
    C[i]:=reduce_mod_pN_K(C[i],p,N);
  end for;
  return Parent(f)!C;
end function;

reduce_mod_pN_Kxmodrl:=function(f,p,N);

  // Reduce an element f of Kx/(r)[l] mod p^N.

  C:=Coefficients(f);
  for i:=1 to #C do
    C[i]:=reduce_mod_pN_Kx(C[i],p,N);  
  end for;
  return Parent(f)!C;
end function;

reduce_mod_pN_Kttinv:=function(f,p,N); 

  // Reduce an element of K[t,t^{-1}] mod p^N.

  if f eq 0 then
    return f;
  else
    C:=Coefficients(f);
    val:=Valuation(f);
    for i:=1 to #C do
      C[i]:=reduce_mod_pN_K(C[i],p,N);
    end for;
  end if;
  return (Parent(f).1)^val*(Parent(f)!C);
end function;

det_Kxmodrl_mod_pN:=function(A,p,N)

  // Compute the determinant of A mod p^N 
  // by expanding along the first row.
  
  rows:=NumberOfRows(A);
  if rows eq 1 then
    det:=reduce_mod_pN_Kxmodrl(A[1,1],p,N);
    return det;
  else
    det:=Parent(A[1,1])!0;
    for i:=1 to rows do
      B:=RemoveColumn(RemoveRow(A,1),i);
      det:=det+(-1)^(i-1)*A[1,i]*$$(B,p,N);
    end for;
    det:=reduce_mod_pN_Kxmodrl(det,p,N);
    return det;
  end if;

end function;

red_mat_fin:=function(Q,p,n,N,rK,G0,Kx);

  // Compute (rG0-lr')^(-1) mod r.

  M0:=rK*G0;

  lc_rK:=LeadingCoefficient(rK);
  rK:=Numerator(rK/lc_rK);
  rK:=reduce_mod_pN_Kx(rK,p,N); 

  Kxmodr:=quo<Kx|rK>;
  rprime:=Kxmodr!Derivative(rK);
  Kxmodrl<l>:=PolynomialRing(Kxmodr);
  
  d:=Degree(Q);
  mat:=ZeroMatrix(Kxmodrl,d,d);
  for i:=1 to d do
    for j:=1 to d do
      mat[i,j]:=Kxmodrl!(Kxmodr!reduce_mod_pN_Kx(Numerator(M0[i,j]),p,N));
    end for;
  end for;
  mat:=mat/lc_rK;
  for i:=1 to d do
    mat[i,i]:=mat[i,i]-l*rprime;
  end for;
  
  if d lt 5 then		
    det:=det_Kxmodrl_mod_pN(mat,p,N); // slow for large d
  else
    det:=reduce_mod_pN_Kxmodrl(Determinant(mat),p,N);
  end if;

  inv:=ZeroMatrix(Kxmodrl,d,d);
  for i:=1 to d do
    for j:=1 to d do
      A:=RemoveColumn(RemoveRow(mat,j),i);
      if d lt 5 then
        inv[i,j]:=(-1)^(i+j)*det_Kxmodrl_mod_pN(A,p,N); // slow for large d
      else
        inv[i,j]:=reduce_mod_pN_Kxmodrl(Cofactor(mat,j,i),p,N);
      end if;
    end for;
  end for;

  return det,inv; // output: det, inv with (rG0-lr')^(-1)=inv/det
end function;

red_mat_inf:=function(Q,p,n,N,rK,Ginf,Kx)

  // Compute (G^{inf}_{-1}-k)^(-1).
  
  d:=Degree(Q);
 
  res_Ginf:=-Evaluate((1/Parent(Ginf[1,1]).1)*Evaluate(Ginf,1/Parent(Ginf[1,1]).1),0); // this is G^{inf}_{-1}
  
  mat:=ChangeRing(res_Ginf,Kx);
  for i:=1 to d do
      mat[i,i]:=mat[i,i]-Kx.1;
  end for;

  det:=Determinant(mat);
  inv:=ZeroMatrix(Kx,d,d);
  for i:=1 to d do
    for j:=1 to d do
      inv[i,j]:=Cofactor(mat,j,i);
    end for;
  end for;

  return det,inv; // output: det, inv with (G^{inf}_{-1}-k)^(-1)=inv/det
end function;

crt:=function(f,facrK,Kx)

  // Compute the isomorphism crt: Q[x]/(r) -> \prod_i Q[x]/(r_i), 
  // where r_i are the irreducible factors of r which is squarefree

  flist:=[**];
  for i:=1 to #facrK do
    ri:=facrK[i][1];
    lc_ri:=LeadingCoefficient(ri);
    ri:=Numerator(ri/lc_ri);
    Kxmodri:=quo<Kx|ri>;
    flist:=Append(flist,Kxmodri!((Kx!f) mod ri));
  end for;
  
  return flist;
end function;

crt_inv:=function(flist,rK,facrK,Kxmodr);

  // Compute the isomorphism crt_inv: \prod_i K[x]/(r_i) -> K[x]/(r),
  // where r_i are the irreducible factors of r which is squarefree

  Kx:=Parent(rK);
  fseq:=[Kx|];
  riseq:=[Kx|];
  for i:=1 to #facrK do
    fseq[i]:=Kx!flist[i];
    riseq[i]:=Kx!facrK[i][1];
  end for;
  f:=Kxmodr!(ChineseRemainderTheorem(fseq,riseq));

  return Kxmodr!f;
end function;

inv_Kxmodri:=function(f,p,n,N,ri);

  K:=BaseRing(Parent(f));
  C:=Coefficients(f);
  
  valset:=[];
  for i:=1 to #C do
    for j:=1 to n do
      if C[i][j] ne 0 then
        valset:=Append(valset,Valuation(C[i][j],p));
      end if;
    end for;
  end for;
  val:=Minimum(valset);
  
  N:=N+val;
  f:=f/p^(val);
  
  Fq:=FiniteField(p^n);
  Fqx:=PolynomialRing(Fq);
  
  rimodp:=Fqx!0;
  C:=Coefficients(ri);
  for i:=1 to #C do
    for j:=1 to n do
      rimodp:=rimodp+(Fq!C[i][j])*(Fq.1)^(j-1)*(Fqx.1)^(i-1);
    end for;
  end for;
  
  Fqxmodri:=quo<Fqx|Fqx!rimodp>;
  
  fmodp:=Fqxmodri!0;
  C:=Coefficients(f);
  for i:=1 to #C do
    for j:=1 to n do
      fmodp:=fmodp+(Fq!C[i][j])*(Fq.1)^(j-1)*(Fqxmodri.1)^(i-1);
    end for;
  end for;

  invmodp:=1/fmodp;

  inv:=Parent(f)!0;
  C:=Coefficients(invmodp);
  for i:=1 to #C do
    D:=ElementToSequence(C[i]);
    for j:=1 to #D do
      inv:=inv+(Z!D[j])*(K.1)^(j-1)*(Parent(f).1)^(i-1);
    end for;
  end for;
  
  prec:=[];
  while N gt 1 do
    prec:=Append(prec,N);
    N:=Ceiling(N/2);
  end while;
  prec:=Reverse(prec);
  
  for i:=1 to #prec do
    inv:=reduce_mod_pN_Kx(inv*(2-inv*f),p,prec[i]);
  end for; 
  
  return inv/(p^(val));

end function;

inv_Kxmodr:=function(f,p,n,N,rK,facrK,Kx);

  // Compute the inverse of an element of K[x]/(r) mod p^N by Hensel lifting.

  flist:=crt(f,facrK,Kx);
  for i:=1 to #flist do
    flist[i]:=inv_Kxmodri(flist[i],p,n,N,facrK[i][1]);
  end for;
  invf:=reduce_mod_pN_Kx(crt_inv(flist,rK,facrK,Parent(f)),p,N);

  return invf;
end function;

red_mat_fin_l:=function(Q,p,n,N,rK,det,inv,l,facrK,Kx);

  // Specialize the matrix det/inv from red_mat_fin at a concrete value l.

  d:=Degree(Q);
  K:=BaseRing(Kx);
  mat:=Evaluate(inv,l)*inv_Kxmodr(Evaluate(det,l),p,n,N,rK,facrK,Kx);
  
  mat_new:=ZeroMatrix(Kx,d,d);
  for i:=1 to d do
    for j:=1 to d do
      C:=Coefficients(mat[i,j]);
      for k:=1 to #C do
        for o:=1 to n do
          mat_new[i,j]:=reduce_mod_pN_Kx(mat_new[i,j]+C[k][o]*(Kx.1)^(k-1)*(K.1)^(o-1),p,N);
        end for;
      end for;
    end for;
  end for;

  return mat_new; 
end function;

red_mat_inf_k:=function(Q,p,n,N,rK,det,inv,k,Kx);

  // Specialize the matrix det/inv from red_mat_inf at a concrete value k.

  return Evaluate(inv,k)/Evaluate(det,k); 
end function;

red_lists:=function(Q,p,n,N,r,W0,Winf,G0,Ginf,e_0,e_inf,Kx) 

  // Compute the lists of values of red_mat_fin_l and red_mat_inf_k that we need.

  d:=Degree(Q);
  rK:=Zax_to_Kx(r,Kx);
  facrK:=Factorization(rK);

  W:=Winf*W0^(-1);

  N0:=Floor(log(p,p*e_0*(N-1)))+1; //
  
  det,inv:=red_mat_fin(Q,p,n,N+2*N0,rK,G0,Kx); 
  
  red_list_fin:=[];
  for i:=1 to p*(N-1) do 
    red_list_fin[i]:=red_mat_fin_l(Q,p,n,N,rK,det,inv,i,facrK,Kx);
  end for;

  Ninf:=Floor(log(p,-p*(ord_0_mat(W)+1)*e_inf)-ord_inf_mat(W^(-1)))+1; //
  
  det,inv:=red_mat_inf(Q,p,n,N+2*Ninf,rK,Ginf,Kx); 

  red_list_inf:=[];
  for i:=1 to  (-p*(ord_0_mat(W)+ord_inf_mat(W)+1)-ord_inf_mat(W^(-1))) do
    red_list_inf[i]:=red_mat_inf_k(Q,p,n,N,rK,det,inv,i,Kx);
  end for;
  
  return red_list_fin, red_list_inf;
end function;

convert_to_Kxzzinvd:=function(w,Q,Kx); 

  // Converts an element of S^d to one of (K[x][z,z^{-1}])^d 

  d:=Degree(Q);
  Kxz<z>:=LaurentSeriesRing(Kx);
  
  C:=[];
  for i:=1 to d do
    D,val:=Coefficients(w[i]);
    E:=[];
    for j:=1 to #D do
      E[j]:=Zax_to_Kx(Zax!Coefficients(D[j]),Kx); 
    end for;
    C[i]:=z^(-1)*(Kxz.1)^(val+1)*(Kxz!E); // check z^(-1), seems necessary
  end for;
  
  return C;
end function;

val_Kxz_d:=function(v)

  // Compute the valuation of an element of (K[x][z,z^{-1}])^d.  

  val:=Valuation(v[1]);
  for i:=2 to #Eltseq(v) do
    if Valuation(v[i]) lt val then
      val:=Valuation(v[i]);
    end if;
  end for;
  return val;
end function;

coho_red_fin:=function(w,Q,p,N,r,G0,red_list_fin,Kx); 

  // Reduce the 1-form w dx/r w.r.t. the basis [y^0,..,y^{d-1}] in cohomology 
  // until it has logaritmic poles at all points lying over the zeros of r.

  Kxz:=LaurentSeriesRing(Kx);
  d:=Degree(Q);
  V:=RSpace(Kx,d);

  rK:=Zax_to_Kx(r,Kx);
  lc_rK:=LeadingCoefficient(rK);
  rK:=Numerator(rK/lc_rK);

  M0:=ZeroMatrix(Kx,d,d);
  for i:=1 to d do 
    for j:=1 to d do 
      M0[i,j]:=reduce_mod_pN_Kx(Numerator(rK*G0[i,j]),p,N); 
    end for; 
  end for; 
  rK:=reduce_mod_pN_Kx(rK,p,N);

  zero:=true;
  for i:=1 to d do
    if w[i] ne 0 then
      zero:=false;
    end if;
  end for;

  if zero then
    return w;
  end if;

  l0:=-val_Kxz_d(w);
  if l0 le 0 then
    return w;
  end if;

  wcoefs:=[];
  for i:=1 to d do
    vec:=[Kx|];
    for j:=-l0 to 0 do
      vec[j+l0+1]:=Coefficient(w[i],j);  
    end for;
    wcoefs:=Append(wcoefs,vec);
  end for;

  l:=l0;
  while l gt 0 do
    wvec:=V!0;
    for i:=1 to d do
      wvec[i]:=wcoefs[i][-l+l0+1];
    end for;
    red_mat:=red_list_fin[l];
    vvec:=wvec*red_mat;
    for i:=1 to d do
      vvec[i]:=vvec[i] mod rK;
    end for;
    mat:=ZeroMatrix(Kx,d,d);
    for i:=1 to d do
      for j:=1 to d do
        mat[i,j]:=M0[i,j];
      end for;
    end for;
    for i:=1 to d do
      mat[i,i]:=mat[i,i]-l*Derivative(rK);
    end for;
    uvec:=wvec-vvec*mat; 
    for i:=1 to d do
      uvec[i]:=reduce_mod_pN_Kx((uvec[i] div rK)-Derivative(vvec[i]),p,N);
    end for; 
    for i:=1 to d do
      wcoefs[i][-l+l0+1]:=wcoefs[i][-l+l0+1]-wvec[i];
      wcoefs[i][-l+l0+2]:=wcoefs[i][-l+l0+2]+uvec[i]; 
    end for;
    l:=l-1;
  end while;
  
  for i:=1 to d do    
    C:=[];
    C[1]:=wcoefs[i][l0+1];
    if w[i] ne 0 then
      for j:=1 to Degree(w[i]) do
        C[j+1]:=Coefficient(w[i],j);  
      end for;
    end if; 
    w[i]:=(Kxz!C);
  end for;

  return w;
end function;

eval_pN:=function(f,g,p,N);  

  // Evaluate f at g mod p^N.

  if f eq 0 then
    return CoefficientRing(Parent(f))!0;
  end if;

  k:=Ceiling((Degree(f)+1)/4);
  h:=[];
  for i:=0 to k-1 do
    h[i+1]:=CoefficientRing(Parent(f))!Coefficient(f,4*i+3);
    for j:=1 to 3 do
      h[i+1]:=reduce_mod_pN_Kx(h[i+1]*g+Coefficient(f,4*i+3-j),p,N);
    end for;
  end for;
  h[k+1]:=0;

  gpow:=reduce_mod_pN_Kx(g^4,p,N);

  while k gt 1 do
    h_old:=h;
    h:=[];
    k:=Ceiling(k/2);
    for i:=0 to k-1 do
      h[i+1]:=reduce_mod_pN_Kx(h_old[2*i+1]+h_old[2*i+2]*gpow,p,N);  
    end for;
    h[k+1]:=0;
    if k gt 1 then
      gpow:=reduce_mod_pN_Kx(gpow^2,p,N);  
    end if;
  end while;
 
  return h[1];
end function;

change_basis_b0binf:=function(w,p,N,r,W0,Winf,Kx);

  // Change basis from [b^0_0,..b^0_(d-1)] to [b^{inf}_0,..,b^{inf}_{d-1}].

  K:=BaseRing(Kx);
  d:=NumberOfRows(Winf);

  rK:=Zax_to_Kx(r,Kx);
  lc_rK:=LeadingCoefficient(rK);
  rK:=reduce_mod_pN_Kx(Numerator(rK/lc_rK),p,N); 
  
  Kttinv<t>:=LaurentSeriesRing(K);
  Kttinvd:=RSpace(Kttinv,d);
  
  W:=Winf*W0^(-1);
  Winv:=W^(-1);
  wnew:=Kttinvd!0;
  for i:=1 to d do
    temp:=eval_pN(w[i],rK,p,N);
    if temp eq 0 then
      wnew[i]:=Kttinv!0;
    else
      wnew[i]:=t^(-Degree(temp))*(Kttinv!Reverse(Coefficients(temp)));
    end if;
  end for;
  w:=wnew*Evaluate(Winv,t^(-1));

  return w;
end function;

coho_red_inf:=function(w,Q,p,N,r,W0,Winf,Ginf,red_list_inf,Kx);

  // Reduce the 1-form w dx/r w.r.t. the basis [b^{inf}_0,..,b^{inf}_{d-1}] in cohomology,
  // lowering the pole order at the point lying over the point at infinity.

  K:=BaseRing(Kx);
  d:=Degree(Q);
  Kd:=RSpace(K,d);

  Kttinv<t>:=LaurentSeriesRing(K);
  Kttinvd:=RSpace(Kttinv,d);
  
  degr:=Degree(r);

  zero:=true;
  for i:=1 to d do
    if w[i] ne 0 then
      zero:=false;
    end if;
  end for;

  if zero then
    return w;
  end if;
  
  W:=Winf*W0^(-1);  
  ord0W:=ord_0_mat(W);

  rK:=Zax_to_Kx(r,Kx);
  Minf:=rK*Ginf;
  lc_rK:=LeadingCoefficient(rK);
  rK:=Numerator(rK/lc_rK);
  Minf:=Minf/lc_rK;

  Minftinv:=Evaluate(Minf,t^(-1));
  rtinv:=Evaluate(rK,1/t);

  rtinv:=reduce_mod_pN_Kttinv(rtinv,p,N); 
  for i:=1 to NumberOfRows(Minftinv) do 
    for j:=1 to NumberOfColumns(Minftinv) do 
      Minftinv[i,j]:=reduce_mod_pN_Kttinv(Minftinv[i,j],p,N); 
    end for; 
  end for; 

  vallist:=[];
  deglist:=[0];
  for i:=1 to d do
    if w[i] ne 0 then
      vallist:=Append(vallist,Valuation(w[i]));
      deglist:=Append(deglist,Degree(w[i]));
    end if;
  end for;

  valw:=Minimum(vallist);
  degw:=Maximum(deglist);
   
  wcoefs:=[];
  for i:=1 to d do
    vec:=[K|];
    for j:=valw to degw do
      vec[j-valw+1]:=Coefficient(w[i],j);  
    end for;
    wcoefs:=Append(wcoefs,vec);
  end for;

  m0:=-valw-degr+1;

  m:=m0;
  while m gt -(ord0W+1) do
    wvec:=Kd!0;
    for i:=1 to d do
      wvec[i]:=-wcoefs[i][-m+m0+1];
    end for;
    red_mat:=red_list_inf[m];
    vvec:=wvec*red_mat;
    dif:=((Kttinvd!vvec)*t^(-m)*Minftinv)+rtinv*m*t^(1-m)*(Kttinvd!vvec);
    for i:=1 to d do
      difmodpN:=reduce_mod_pN_Kttinv(dif[i],p,N);
      C,val:=Coefficients(difmodpN);
      for j:=1 to #C do
        wcoefs[i][j+val-1+m0+degr]:=wcoefs[i][j+val-1+m0+degr]-C[j];
      end for;
    end for;
    m:=m-1;
  end while;

  for i:=1 to d do
    w[i]:=reduce_mod_pN_Kttinv(t^(-m0-degr+1)*(Kttinv!wcoefs[i]),p,N);
  end for;    

  return w;
end function;

change_basis_binfb0:=function(w,W0,Winf,Kx);

  // Change basis from [b^{inf}_0,..,b^{inf}_{d-1}] to [b^0_0,..b^0_(d-1)].

  t:=Parent(w[1]).1;
  
  W:=Winf*W0^(-1);
  w:=w*Evaluate(W,t^(-1));
  w:=Evaluate(w,t^(-1));
  for i:=1 to NumberOfColumns(w) do
    temp:=w[1,i];
    if temp ne 0 then
      for j:=Valuation(temp) to -1 do
        temp:=temp-Coefficient(temp,j)*t^j;
      end for;
    end if;
    w[1,i]:=temp;
  end for;
  w:=Evaluate(w,Kx.1);
  return w;
end function;
