////////////////////////////////////////////////// 
// This code is part of the pcc_p MAGMA library //
//                                              //
// copyright (c) 2016 Jan Tuitman               //
//////////////////////////////////////////////////

reduce_mod_pN_Q:=function(f,p,N);

  // Reduce a rational number f mod p^N.

  if f ne 0 then
    ord:=Valuation(f,p);
    if ord ge N then
      f:=0;
    else
      m:=p^(N-ord);
      Zmodm:=IntegerRing(m);
      unit:=f/(p^ord);
      f:=Z!((Zmodm!Numerator(unit))/(Zmodm!Denominator(unit)));
      if 2*f ge m then
        f:=f-m;
      end if;
      f:=p^ord*(RationalField()!f);
    end if;
  end if;
  return f;
end function;

reduce_mod_pN_Qx:=function(f,p,N);

  // Reduce a univariate polynomial over the rational numbers f mod p^N.

  C:=Coefficients(f);
  for i:=1 to #C do
    C[i]:=reduce_mod_pN_Q(C[i],p,N);
  end for;
  return Parent(f)!C;
end function;

reduce_mod_pN_Qxmodrl:=function(f,p,N);

  // Reduce an element f of Qx/(r)[l] mod p^N.

  C:=Coefficients(f);
  for i:=1 to #C do
    C[i]:=reduce_mod_pN_Qx(C[i],p,N);  
  end for;
  return Parent(f)!C;
end function;

reduce_mod_pN_Qttinv:=function(f,p,N); 

  // Reduce an element of Q[t,t^{-1}] mod p^N.

  if f eq 0 then
    return f;
  else
    C:=Coefficients(f);
    val:=Valuation(f);
    for i:=1 to #C do
      C[i]:=reduce_mod_pN_Q(C[i],p,N);
    end for;
  end if;
  return (Parent(f).1)^val*(Parent(f)!C);
end function;

det_Qxmodrl_mod_pN:=function(A,p,N)

  // Compute the determinant of A mod p^N 
  // by expanding along the first row.
  
  rows:=NumberOfRows(A);
  if rows eq 1 then
    det:=reduce_mod_pN_Qxmodrl(A[1,1],p,N);
    return det;
  else
    det:=Parent(A[1,1])!0;
    for i:=1 to rows do
      B:=RemoveColumn(RemoveRow(A,1),i);
      det:=det+(-1)^(i-1)*A[1,i]*$$(B,p,N);
    end for;
    det:=reduce_mod_pN_Qxmodrl(det,p,N);
    return det;
  end if;

end function;

red_mat_fin:=function(Q,p,N,rQ,G0); 

  // Compute (rG0-lr')^(-1) mod r.

  M0:=rQ*G0;

  Qx:=PolynomialRing(RationalField());
  lc_rQ:=LeadingCoefficient(rQ);
  rQ:=Numerator(rQ/lc_rQ);
  
  C:=Coefficients(rQ);
  size:=1;
  for i:=1 to #C do
    coefsize:=AbsoluteValue(Numerator(C[i])*Denominator(C[i]));
    if coefsize gt size then
      size:=coefsize;
    end if;    
  end for;
  if size gt p^N then 
    rQ:=reduce_mod_pN_Qx(rQ,p,N);
  end if;

  Qxmodr:=quo<Qx|rQ>;
  rprime:=Qxmodr!Derivative(rQ);
  Qxmodrl<l>:=PolynomialRing(Qxmodr);

  d:=Degree(Q);
  mat:=ZeroMatrix(Qxmodrl,d,d);
  for i:=1 to d do
    for j:=1 to d do
      mat[i,j]:=Qxmodrl!(Qxmodr!reduce_mod_pN_Qx(Qx!M0[i,j],p,N));
    end for;
  end for;
  mat:=mat/lc_rQ;
  for i:=1 to d do
    mat[i,i]:=mat[i,i]-l*rprime;
  end for;

  if d lt 7 then 
    det:=det_Qxmodrl_mod_pN(mat,p,N); // slow for large d!
  else
    det:=Determinant(mat);
    det:=reduce_mod_pN_Qxmodrl(det,p,N);
  end if;

  inv:=ZeroMatrix(Qxmodrl,d,d);
  for i:=1 to d do
    for j:=1 to d do
      A:=RemoveColumn(RemoveRow(mat,j),i);
      if d lt 7 then 
        inv[i,j]:=(-1)^(i+j)*det_Qxmodrl_mod_pN(A,p,N); // slow for large d!
      else
        inv[i,j]:=Cofactor(mat,j,i);
        inv[i,j]:=reduce_mod_pN_Qxmodrl(inv[i,j],p,N);
      end if; 
    end for;
  end for;

  return det,inv; // output: det, inv with (rG0-lr')^(-1)=inv/det
end function;

red_mat_inf:=function(Q,p,N,rQ,Ginf)

  // Compute (G^{inf}_{-1}-k)^(-1).
  
  Qk<k>:=PolynomialRing(RationalField());
  d:=Degree(Q);

  res_Ginf:=-Evaluate((1/Parent(Ginf[1,1]).1)*Evaluate(Ginf,1/Parent(Ginf[1,1]).1),0); // this is G^{inf}_{-1}
  
  mat:=ChangeRing(res_Ginf,Qk);
  for i:=1 to d do
      mat[i,i]:=mat[i,i]-k;
  end for;

  det:=Determinant(mat);
  inv:=ZeroMatrix(Qk,d,d);
  for i:=1 to d do
    for j:=1 to d do
      inv[i,j]:=Cofactor(mat,j,i);
    end for;
  end for;

  return det,inv; // output: det, inv with (G^{inf}_{-1}-k)^(-1)=inv/det
end function;

crt:=function(f,rQ,facrQ)

  // Compute the isomorphism crt: Q[x]/(r) -> \prod_i Q[x]/(r_i), 
  // where r_i are the irreducible factors of r which is squarefree

  Qx<x>:=PolynomialRing(RationalField());
  flist:=[**];
  for i:=1 to #facrQ do
    ri:=facrQ[i][1];
    lc_ri:=LeadingCoefficient(ri);
    ri:=Numerator(ri/lc_ri);
    Qxmodri:=quo<Qx|ri>;
    flist:=Append(flist,Qxmodri!((Qx!f) mod ri));
  end for;
  
  return flist;
end function;

crt_inv:=function(flist,rQ,facrQ);

  // Compute the isomorphism crt_inv: \prod_i Q[x]/(r_i) -> Q[x]/(r),
  // where r_i are the irreducible factors of r which is squarefree

  Qx<x>:=PolynomialRing(RationalField());
  lc_rQ:=LeadingCoefficient(rQ);
  rQ:=Numerator(rQ/lc_rQ);
  Qxmodr:=quo<Qx|rQ>;
  fseq:=[Qx|];
  riseq:=[Qx|];
  for i:=1 to #facrQ do
    fseq[i]:=Qx!flist[i];
    riseq[i]:=Qx!facrQ[i][1];
  end for;
  f:=ChineseRemainderTheorem(fseq,riseq) mod rQ;

  return Qxmodr!f;
end function;

inv_Qxmodri:=function(f,p,N,ri);

  Z:=IntegerRing();  
  Fp:=FiniteField(p);
  Fpx:=PolynomialRing(Fp);

  C:=Coefficients(f);
  valset:=[];
  for i:=1 to #C do
    if C[i] ne 0 then
      valset:=Append(valset,Valuation(C[i],p));
    end if;
  end for;
  valf:=Minimum(valset);
  f:=f*p^(-valf);
  N:=N+valf;

  rimodp:=Fpx!0;
  C:=Coefficients(ri);
  for i:=1 to #C do
    rimodp:=rimodp+(Fp!C[i])*(Fpx.1)^(i-1);
  end for;
  Fpxmodri:=quo<Fpx|Fpx!rimodp>;
  fmodp:=Fpxmodri!0;
  C:=Coefficients(f);
  for i:=1 to #C do
      fmodp:=fmodp+(Fp!C[i])*(Fpxmodri.1)^(i-1);
  end for;
  invmodp:=1/fmodp;
  inv:=Parent(f)!0;
  C:=Coefficients(invmodp);
  for i:=1 to #C do
      inv:=inv+(Z!C[i])*(Parent(f).1)^(i-1);
  end for;
  prec:=[];
  while N gt 1 do
    prec:=Append(prec,N);
    N:=Ceiling(N/2);
  end while;
  prec:=Reverse(prec);
  for i:=1 to #prec do
    inv:=reduce_mod_pN_Qx(inv*(2-inv*f),p,prec[i]);
  end for; 
  return p^(-valf)*inv;
end function;

inv_Qxmodr:=function(f,p,N,rQ,facrQ);

  // Compute the inverse of an element of Q[x]/(r) mod p^N.

  Z:=IntegerRing();  
  Qx:=PolynomialRing(RationalField());
  
  flist:=crt(f,rQ,facrQ);
  for i:=1 to #flist do
    flist[i]:=inv_Qxmodri(flist[i],p,N,facrQ[i][1]);
  end for;
  invf:=reduce_mod_pN_Qx(crt_inv(flist,rQ,facrQ),p,N);

  return invf;
end function;

red_mat_fin_l:=function(Q,p,N,rQ,det,inv,l,facrQ);

  // Specialize the matrix det/inv from red_mat_fin at a concrete value l.

  d:=Degree(Q);
  Qx<x>:=PolynomialRing(RationalField());  
  detl:=Evaluate(det,l); // naive evaluation
  
  C:=Coefficients(detl);
  valset:=[];
  for i:=1 to #C do
    if C[i] ne 0 then
      valset:=Append(valset,Valuation(C[i],p));
    end if;
  end for;
  valdetl:=Minimum(valset);

  detl:=reduce_mod_pN_Qx(detl/(p^valdetl),p,N+valdetl); 
  for i:=1 to d do
    for j:=1 to d do
      D:=Coefficients(inv[i,j]);
     for k:=1 to #D do
        D[k]:=reduce_mod_pN_Qx(D[k],p,N+valdetl);
      end for;
      inv[i,j]:=Parent(inv[i,j])!D;
    end for;
  end for;
 
  invl:=Evaluate(inv,l); // naive evaluation
  mat:=invl*p^(-valdetl)*(Parent(invl[1,1])!Coefficients(inv_Qxmodr(detl,p,N+valdetl,rQ,facrQ)));

  mat_new:=ZeroMatrix(Qx,d,d);
  for i:=1 to d do
    for j:=1 to d do
      mat_new[i,j]:=reduce_mod_pN_Qx(mat[i,j],p,N); 
    end for;
  end for;

  return mat_new; 
end function;

red_mat_inf_k:=function(Q,p,N,rQ,det,inv,k);

  // Specialize the matrix det/inv from red_mat_inf at a concrete value k.

  d:=Degree(Q);
  mat:=Evaluate(inv,k)/Evaluate(det,k); // just inverting a rational number, so no Hensel lift
  for i:=1 to d do
    for j:=1 to d do
      mat[i,j]:=reduce_mod_pN_Q(mat[i,j],p,N); 
    end for;
  end for;
  return mat;
end function;

red_lists:=function(Q,p,N,r,W0,Winf,G0,Ginf,J0,Jinf) 

  // Compute the lists of values of red_mat_fin_l and red_mat_inf_k that we need.

  Qx:=PolynomialRing(RationalField());
  rQ:=Qx!r;
  facrQ:=Factorization(rQ);

  W:=Winf*W0^(-1);
  e_0,e_inf:=ram(J0,Jinf);

  N0:=Floor(log(p,p*e_0*(N-1)))+1; // 

  det,inv:=red_mat_fin(Q,p,N+2*N0,rQ,G0); // what about this 2?

  red_list_fin:=[];
  for i:=1 to p*(N-1) do
    red_list_fin[i]:=red_mat_fin_l(Q,p,N+N0,rQ,det,inv,i,facrQ);
  end for;
 
  Ninf:=Floor(log(p,-p*(ord_0_mat(W)+1)*e_inf)-ord_inf_mat(W^(-1)))+1; // typo?

  det,inv:=red_mat_inf(Q,p,N+N0+2*Ninf,rQ,Ginf); 

  red_list_inf:=[];
  for i:=1 to (-p*(ord_0_mat(W)+ord_inf_mat(W)+1)-ord_inf_mat(W^(-1))) do
    red_list_inf[i]:=red_mat_inf_k(Q,p,N+N0+Ninf,r,det,inv,i);
  end for;

  return red_list_fin, red_list_inf;
end function;

convert_to_Qxzzinvd:=function(w,Q); 

  // Converts an element of S^d to one of (Q[x][z,z^{-1}])^d 

  d:=Degree(Q);
  Z:=IntegerRing();
  Qx<x>:=PolynomialRing(RationalField());
  Qxz<z>:=LaurentSeriesRing(Qx);
  C:=[];
  for i:=1 to d do
    D,val:=Coefficients(w[i]);
    E:=[];
    for j:=1 to #D do
      E[j]:=(Zx!D[j]);  
    end for;
    C[i]:=z^(-1)*(Qxz.1)^(val+1)*(Qxz!E); 
  end for;
  
  return C;
end function;

val_Qxz_d:=function(v)

  // Compute the valuation of an element of (Q[x][z,z^{-1}])^d.  

  val:=Valuation(v[1]);
  for i:=2 to #Eltseq(v) do
    if Valuation(v[i]) lt val then
      val:=Valuation(v[i]);
    end if;
  end for;
  return val;
end function;

coho_red_fin:=function(w,Q,p,N,r,G0,red_list_fin); 

  // Reduce the 1-form w dx/r w.r.t. the basis [b^0_0,..,b^0_{d-1}] in cohomology 
  // until it has logaritmic poles at all points lying over the zeros of r.

  Qx<x>:=PolynomialRing(RationalField());
  Qxz<z>:=LaurentSeriesRing(Qx);
  d:=Degree(Q);
  V:=RSpace(Qx,d);

  M:=r*G0;

  r:=Qx!r;
  lc_r:=LeadingCoefficient(r);
  r:=Numerator(r/lc_r);
  
  r:=reduce_mod_pN_Qx(r,p,N); 
  for i:=1 to NumberOfRows(M) do 
    for j:=1 to NumberOfColumns(M) do 
      M[i,j]:=Parent(M[i,j])!reduce_mod_pN_Qx(Numerator(M[i,j]),p,N); 
    end for; 
  end for; 

  zero:=true;
  for i:=1 to d do
    if w[i] ne 0 then
      zero:=false;
    end if;
  end for;

  if zero then
    return w;
  end if;

  l0:=-val_Qxz_d(w);
  if l0 le 0 then
    return w;
  end if;

  wcoefs:=[];
  for i:=1 to d do
    vec:=[Qx|];
    for j:=-l0 to 0 do
      vec[j+l0+1]:=Coefficient(w[i],j);  
    end for;
    wcoefs:=Append(wcoefs,vec);
  end for;

  l:=l0;
  while l gt 0 do
    wvec:=V!0;
    for i:=1 to d do
      wvec[i]:=wcoefs[i][-l+l0+1];
    end for;
    red_mat:=red_list_fin[l];
    vvec:=wvec*red_mat;
    for i:=1 to d do
      vvec[i]:=vvec[i] mod r;
    end for;
    mat:=ZeroMatrix(Qx,d,d);
    for i:=1 to d do
      for j:=1 to d do
        mat[i,j]:=(Qx!Numerator(M[i,j]));
      end for;
    end for;
    mat:=mat/lc_r;
    for i:=1 to d do
      mat[i,i]:=mat[i,i]-l*(Qx!Coefficients(Derivative(r)));
    end for;
    uvec:=wvec-vvec*mat; 
    for i:=1 to d do
      uvec[i]:=reduce_mod_pN_Qx((uvec[i] div r)-Derivative(vvec[i]),p,N);
    end for; 
    for i:=1 to d do
      wcoefs[i][-l+l0+1]:=wcoefs[i][-l+l0+1]-wvec[i];
      wcoefs[i][-l+l0+2]:=wcoefs[i][-l+l0+2]+uvec[i]; 
    end for;
    l:=l-1;
  end while;
  
  for i:=1 to d do 
    C:=[];   
    C[1]:=wcoefs[i][l0+1];   
    if w[i] ne 0 then
      for j:=1 to Degree(w[i]) do
        C[j+1]:=Coefficient(w[i],j);  
      end for;
    end if; 
    w[i]:=(Qxz!C);
  end for;

  return w;
end function;

eval_pN:=function(f,g,p,N);  

  // Evaluate f at g mod p^N.

  if f eq 0 then
    return CoefficientRing(Parent(f))!0;
  end if;

  k:=Ceiling((Degree(f)+1)/4);
  h:=[];
  for i:=0 to k-1 do
    h[i+1]:=CoefficientRing(Parent(f))!Coefficient(f,4*i+3);
    for j:=1 to 3 do
      h[i+1]:=h[i+1]*g+Coefficient(f,4*i+3-j);
    end for;
  end for;
  h[k+1]:=0;

  gpow:=reduce_mod_pN_Qx(g^4,p,N);

  while k gt 1 do
    h_old:=h;
    h:=[];
    k:=Ceiling(k/2);
    for i:=0 to k-1 do
      h[i+1]:=reduce_mod_pN_Qx(h_old[2*i+1]+h_old[2*i+2]*gpow,p,N);  
    end for;
    h[k+1]:=0;
    if k gt 1 then
      gpow:=reduce_mod_pN_Qx(gpow^2,p,N);  
    end if;
  end while;
 
  return h[1];
end function;

change_basis_b0binf:=function(w,p,N,r,W0,Winf);

  // Change basis from [b^0_0,..b^0_(d-1)] to [b^{inf}_0,..,b^{inf}_{d-1}].

  Qx<x>:=PolynomialRing(RationalField());
  d:=NumberOfRows(Winf);
  
  r:=Qx!r;
  lc_r:=LeadingCoefficient(r);
  r:=Numerator(r/lc_r); 

  Qttinv<t>:=LaurentSeriesRing(RationalField());
  Qttinvd:=RSpace(Qttinv,d);
  
  W:=Winf*W0^(-1);
  Winv:=W^(-1);
  wnew:=Qttinvd!0;
  for i:=1 to d do
    temp:=eval_pN(w[i],r,p,N);
    if temp eq 0 then
      wnew[i]:=Qttinv!0;
    else
      wnew[i]:=t^(-Degree(temp))*(Qttinv!Reverse(Coefficients(temp)));
    end if;
  end for;
  w:=wnew*Evaluate(Winv,t^(-1));

  return w;
end function;

coho_red_inf:=function(w,Q,p,N,r,W0,Winf,Ginf,red_list_inf);

  // Reduce the 1-form w dx/r w.r.t. the basis [b^{inf}_0,..,b^{inf}_{d-1}] in cohomology,
  // lowering the pole order at the points lying over the point at infinity.

  d:=Degree(Q);
  degr:=Degree(r);

  Qttinv<t>:=LaurentSeriesRing(RationalField());
  Qttinvd:=RSpace(Qttinv,d);
  Qd:=RSpace(RationalField(),d);
  Qx<x>:=PolynomialRing(RationalField());

  zero:=true;
  for i:=1 to d do
    if w[i] ne 0 then
      zero:=false;
    end if;
  end for;

  if zero then
    return w;
  end if;

  Minf:=r*Ginf;
  
  W:=Winf*W0^(-1);  
  ord0W:=ord_0_mat(W);

  r:=Qx!r;
  lc_r:=LeadingCoefficient(r);
  r:=Numerator(r/lc_r);
  Minf:=Minf/lc_r;

  Minftinv:=Evaluate(Minf,t^(-1));
  rtinv:=Evaluate(r,1/t);

  rtinv:=reduce_mod_pN_Qttinv(rtinv,p,N); 
  for i:=1 to NumberOfRows(Minftinv) do 
    for j:=1 to NumberOfColumns(Minftinv) do 
      Minftinv[i,j]:=reduce_mod_pN_Qttinv(Minftinv[i,j],p,N); 
    end for; 
  end for; 

  vallist:=[];
  deglist:=[0];
  for i:=1 to d do
    if w[i] ne 0 then
      vallist:=Append(vallist,Valuation(w[i]));
      deglist:=Append(deglist,Degree(w[i]));
    end if;
  end for;

  valw:=Minimum(vallist);
  degw:=Maximum(deglist);
   
  wcoefs:=[];
  for i:=1 to d do
    vec:=[RationalField()|];
    for j:=valw to degw do
      vec[j-valw+1]:=Coefficient(w[i],j);  
    end for;
    wcoefs:=Append(wcoefs,vec);
  end for;

  m0:=-valw-degr+1;
  
  m:=m0;
  while m gt -(ord0W+1) do
    wvec:=Qd!0;
    for i:=1 to d do
      wvec[i]:=-wcoefs[i][-m+m0+1];
    end for;
    red_mat:=red_list_inf[m];
    vvec:=wvec*red_mat;
    dif:=((Qttinvd!vvec)*t^(-m)*Minftinv)+rtinv*m*t^(1-m)*(Qttinvd!vvec);
    for i:=1 to d do
      difmodpN:=reduce_mod_pN_Qttinv(dif[i],p,N);
      C,val:=Coefficients(difmodpN);
      for j:=1 to #C do
        wcoefs[i][j+val-1+m0+degr]:=wcoefs[i][j+val-1+m0+degr]-C[j];
      end for;
      wcoefs[i][-m+m0+1]:=0;
    end for;
    m:=m-1;
  end while;

  for i:=1 to d do
    w[i]:=reduce_mod_pN_Qttinv(t^(-m0-degr+1)*(Qttinv!wcoefs[i]),p,N);
  end for;  

  return w;
end function;

change_basis_binfb0:=function(w,W0,Winf);

  // Change basis from [b^{inf}_0,..,b^{inf}_{d-1}] to [b^0_0,..b^0_(d-1)].

  Qx<x>:=PolynomialRing(RationalField());
  t:=Parent(w[1]).1;
  
  W:=Winf*W0^(-1);
  w:=w*Evaluate(W,t^(-1));
  w:=Evaluate(w,t^(-1));
  for i:=1 to NumberOfColumns(w) do
    temp:=w[1,i];
    if temp ne 0 then
      for j:=Valuation(temp) to -1 do
        temp:=temp-Coefficient(temp,j)*t^j;
      end for;
    end if;
    w[1,i]:=temp;
  end for;
  w:=Evaluate(w,x);
  return w;
end function;

