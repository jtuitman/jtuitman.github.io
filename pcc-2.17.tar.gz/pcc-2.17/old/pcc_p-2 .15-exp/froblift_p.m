////////////////////////////////////////////////// 
// This code is part of the pcc_p MAGMA library //
//                                              //
// copyright (c) 2016 Jan Tuitman               //
//////////////////////////////////////////////////

getring:=function(p,Q,r,N)

  // Construct rings mod p^N.

  O:=IntegerRing(p^N);
  P<y,x,w,z>:=PolynomialRing(O,4);

  lc:=LeadingCoefficient(r);
  rnew:=P!0;
  for i:=0 to Degree(r) do
    rnew:=rnew+(O!Coefficient(r,i))*x^i;
  end for;

  rnew:=rnew*(O!lc)^(-1);
  r:=rnew;

  Qnew:=P!0;
  for i:=0 to Degree(Q) do
    coef:=Coefficient(Q,i);
    for j:=0 to Degree(coef) do
      Qnew:=Qnew+Coefficient(coef,j)*x^j*y^i;
    end for;
  end for;
  Q:=Qnew;

  R:=quo<P|w*z-1,r-z,Q>;
  
  return R;
end function;


froblift:=function(Q,p,N,r,Delta,s,W0);

  d:=Degree(Q);

  // 1) Compute matrix of F_p on R w.r.t. basis [y^i]

  lc:=LeadingCoefficient(r);

  rQx:=Parent(Numerator(W0[1,1]))!r;
  DeltaQx:=Parent(Numerator(W0[1,1]))!Delta;
  rQx:=rQx/lc;
  DeltaQx:=DeltaQx/lc;

  O,Oz,S,R:=getrings(p,Q,r,N);
  x:=S.1; y:=R.1; z:=Oz.1;

  cnt:=1;
  while (rQx^cnt mod DeltaQx ne 0) do
    cnt:=cnt+1;
  end while;
  gQx:=rQx^cnt div DeltaQx;

  prec:=[];
  k:=N;
  while k gt 1 do
    prec:=Append(prec,k);
    k:=Ceiling(k/2);
  end while;
  prec:=Reverse(prec);

  alpha:=S!(z^(-p));
  beta:=y^p;
  xp:=x^p;	

  for i:=1 to #prec do

    Oi,Ozi,Si,Ri:=getrings(p,Q,r,prec[i]);

    alpha_new:=Si!0;
    for j:=0 to Degree(alpha) do
      coef:=Coefficient(alpha,j);
      val:=Valuation(coef);
      alpha_new:=alpha_new+(Ozi!Coefficients(coef))*(Ozi.1)^val*(Si.1)^j;
    end for;
    alpha:=alpha_new;

    beta_new:=Ri!0;
    for j:=0 to Degree(beta) do
      coef:=Coefficient(beta,j);
      for k:=0 to Degree(coef) do
        coef1:=Coefficient(coef,k);
        val:=Valuation(coef1);
        beta_new:=beta_new+(Ozi!Coefficients(coef1))*(Ozi.1)^val*(Si.1)^k*(Ri.1)^j;
      end for;
    end for;
    beta:=beta_new;

    xpi:=(Si.1)^p;				
    rxp:=Evaluate(r,xpi)*(Oi!lc)^(-1);
    							
    alpha:=alpha*(2-alpha*rxp); // alpha=F_p(1/r)
    alpha_power:=alpha^cnt;

    gxp:=Si!0;
    for j:=0 to Degree(gQx) do
      gxp:=gxp+(Oi!Coefficient(gQx,j))*xpi^j;
    end for;

    alpha1:=gxp*alpha_power;    // alpha1=F_p(1/Delta)

    powers:=[];
    powers[1]:=Ri!1;
    for j:=2 to Degree(Q)+1 do
      powers[j]:=beta*powers[j-1];
    end for;

    Qxpbeta:=Ri!0; 
    for j:=0 to Degree(Q) do
      coef:=Coefficient(Q,j);
      for k:=0 to Degree(coef) do
        Qxpbeta:=Qxpbeta+(Oi!Coefficient(coef,k))*(xpi)^k*powers[j+1];
      end for;
    end for;

    sxpbeta:=Ri!0;
    for j:=0 to Degree(s) do
      coef:=Coefficient(s,j);
      for k:=0 to Degree(coef) do
        sxpbeta:=sxpbeta+(Oi!Coefficient(coef,k))*(xpi)^k*powers[j+1];
      end for;
    end for;
    sxpbeta:=sxpbeta*(Oi!lc)^(-1);								

    beta:=beta-Qxpbeta*sxpbeta*alpha1;

  end for;
  
  alpha_new:=S!0;
  for i:=0 to Degree(alpha) do
    coef:=Coefficient(alpha,i);
    if coef ne 0 then
      val:=Valuation(coef);
      alpha_new:=alpha_new+(Oz!Coefficients(coef))*z^val*x^i;
    end if;
  end for;
  alpha:=alpha_new;

  beta_new:=R!0;
  for i:=0 to Degree(beta) do
    coef:=Coefficient(beta,i);
    for j:=0 to Degree(coef) do
      coef1:=Coefficient(coef,j);
      if coef1 ne 0 then
        val:=Valuation(coef1);
        beta_new:=beta_new+(Oz!Coefficients(coef1))*z^val*x^j*y^i;
      end if;
    end for;
  end for;
  beta:=beta_new;

  // 2) Compute matrix of F_p on R w.r.t. basis [y^i/r]
  
  mat:=ZeroMatrix(S,d,d); 
  Fpyir:=z*(alpha);        		 // r*F_p(y^0/r)
  for i:=1 to d do
    mat[1,i]:=Coefficient(Fpyir,i-1);
  end for;
  for i:=2 to d do
    Fpyir:=beta*Fpyir;                   // r*F_p(y^(j+1)/r) = F_p(y)*(r*F_p(y^j/r))
    for j:=1 to d do
      mat[i,j]:=Coefficient(Fpyir,j-1);
    end for;
  end for;

  // 3) Compute the matrix of F_p on R w.r.t. basis [b^0_i/r] (i.e. Fp(W0)*mat*W0^(-1))

  W0inv:=W0^(-1);
  ordrW0inv:=ord_r_mat(W0inv,rQx);
  W0invS:=ZeroMatrix(S,d,d);
  for i:=1 to d do
    for j:=1 to d do
      W0invS[i,j]:= z^(ordrW0inv)*(S!Coefficients(Numerator((Parent(W0[1,1])!rQx)^(-ordrW0inv)*W0inv[i,j])));  // Compute S!W0^(-1) 
    end for;
  end for;

  mat:=mat*W0invS; // Compute mat*W0^(-1)

  ordrW0:=ord_r_mat(W0,rQx);
  FpW0S:=ZeroMatrix(S,d,d);
  for i:=1 to d do
    for j:=1 to d do
      numQx:=Numerator((Parent(W0[1,1])!rQx)^(-ordrW0)*W0[i,j]);
      numxp:=S!0;
      for k:=0 to Degree(numQx) do
        numxp:=numxp+(O!Coefficient(numQx,k))*xp^k;
      end for;
      FpW0S[i,j]:=alpha^(-ordrW0)*numxp; // Compute S!Fp(W0)
    end for;
  end for;

  mat:=FpW0S*mat; // Compute Fp(W0)*mat*W0^(-1)

  return mat; // matrix of Fp on R w.r.t. basis [b^0_i/r]

end function;

frobenius:=function(w,Q,p,N,r,frobmatb0r)

  // Compute F_p(sum w_i b^0_i dx/r) mod p^N.

  //O,Oz,S,R:=getrings(p,Q,r,N-1);
  //x:=S.1; y:=R.1; z:=Oz.1;

  // less elegant, but makes coercions work:

  S:=Parent(frobmatb0r[1,1]); 
  Oz:=BaseRing(S);
  O:=BaseRing(Oz);
  x:=S.1; z:=Oz.1;

  d:=Degree(Q);

  Sd:=RSpace(S,d);

  xp_minus_one:=x^(p-1);		   
  xp:=xp_minus_one*x; 

  frob:=Sd!0;
  for i:=1 to d do
    wixp:=S!0;
    for j:=0 to Degree(w[i]) do
      wixp:=wixp+(O!Coefficient(w[i],j))*xp^j;
    end for;
    temp:=xp_minus_one*wixp;
    for j:=1 to d do
      frob[j]:=frob[j]+frobmatb0r[i,j]*temp;
    end for;   
  end for;

  O,Oz,S,R:=getrings(p,Q,r,N); // one digit more precision, after multiplying by p
  x:=S.1; y:=R.1; z:=Oz.1;

  Sd:=RSpace(S,d);
  frob_new:=Sd!0;
  for i:=1 to d do
    for j:=0 to Degree(frob[i]) do
      coef:=Coefficient(frob[i],j);
      if coef ne 0 then
        val:=Valuation(coef);
        frob_new[i]:=frob_new[i]+(Oz!Coefficients(coef))*z^val*x^j;
      end if;
    end for;
  end for;
  frob:=frob_new;
 
  frob:=p*frob;

  return frob;   
end function;
